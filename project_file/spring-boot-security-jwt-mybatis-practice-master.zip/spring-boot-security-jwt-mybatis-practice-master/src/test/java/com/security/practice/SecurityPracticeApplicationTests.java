package com.security.practice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecurityPracticeApplicationTests {

	@Test
	void contextLoads() {
	}

}
